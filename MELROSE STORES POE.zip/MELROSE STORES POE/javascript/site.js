document.addEventListener('DOMContentLoaded', () => {
    const lightbox = document.querySelector('#lightbox');
    const lightboxImage = document.querySelector('#lightbox-image');
    document.querySelectorAll('[data-lightbox]').forEach((button) => {
        button.addEventListener('click', () => { lightboxImage.src = button.dataset.lightbox; lightboxImage.alt = button.dataset.alt || 'Melrose Stores image'; lightbox.classList.add('is-open'); lightbox.setAttribute('aria-hidden', 'false'); });
    });
    const closeLightbox = () => { if (!lightbox) return; lightbox.classList.remove('is-open'); lightbox.setAttribute('aria-hidden', 'true'); };
    document.querySelector('[data-close-lightbox]')?.addEventListener('click', closeLightbox);
    lightbox?.addEventListener('click', (event) => { if (event.target === lightbox) closeLightbox(); });
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeLightbox(); });
    const search = document.querySelector('#product-search');
    search?.addEventListener('input', () => { const term = search.value.toLowerCase().trim(); document.querySelectorAll('[data-product]').forEach((product) => { product.hidden = !product.textContent.toLowerCase().includes(term); }); });
    document.querySelectorAll('form[data-form]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            event.preventDefault(); const message = form.querySelector('.form-message');
            if (!form.checkValidity()) { form.classList.add('was-validated'); message.textContent = 'Please complete all required fields correctly.'; message.className = 'form-message error'; form.reportValidity(); return; }
            message.textContent = form.dataset.form === 'enquiry' ? 'Thank you. Your enquiry has been received; we will confirm availability and pricing soon.' : 'Thank you. Your message is ready to send to Melrose Stores.';
            message.className = 'form-message success'; form.reset();
        });
    });
});
