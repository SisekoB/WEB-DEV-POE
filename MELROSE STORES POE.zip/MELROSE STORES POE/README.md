# Melrose Stores – Part 3

# Website

Melrose Stores is a small responsive website for a local grocery store. It includes Home, About, Products, News, Contact and Enquiry pages.

Open `Home.html` in a browser to view the site. 

# Part 3 functionality

- Shared responsive styling in `css/site.css`.
- Shared JavaScript in `javascript/site.js` for image lightboxes, product search, and client-side form validation and responses.
- Products page includes searchable product cards and accessible image lightbox controls.
- About page includes a lazy-loaded Google Map.
- Contact and Enquiry pages include required fields, email validation, minimum message lengths, and clear response messages.
- SEO improvements include page titles, descriptions, keywords, canonical links, semantic headings, descriptive image alt text, `robots.txt`, and `sitemap.xml`.

# Changelog

# Part 3 upgrade

- Replaced duplicated page navigation with a consistent accessible navigation structure.
- Corrected broken Contact links and added a separate Enquiry page as required by the brief.
- Added responsive layout, improved colour contrast, image loading hints, and keyboard-friendly controls.
- Added JavaScript lightbox, product search, form validation, and user feedback messages.
- Removed invalid nested HTML from the Products page.
- Added SEO metadata, canonical links, `robots.txt`, and `sitemap.xml`.
- Added this detailed README entry to document the development work.

## References

- MDN Web Docs, HTML forms and constraint validation: https://developer.mozilla.org/en-US/docs/Learn/Forms
- MDN Web Docs, JavaScript DOM scripting: https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Client-side_web_APIs/Manipulating_documents
- Google Search Central, SEO starter guide: https://developers.google.com/search/docs/fundamentals/seo-starter-guide
- Google Maps Embed API: https://developers.google.com/maps/documentation/embed/get-started
